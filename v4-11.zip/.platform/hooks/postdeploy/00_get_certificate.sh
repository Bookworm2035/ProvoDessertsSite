#!/usr/bin/env bash
# Place in .platform/hooks/postdeploy directory
sudo certbot -n -d mindfulprovo.is404.net --nginx --agree-tos --email bookworm2035@gmail.com